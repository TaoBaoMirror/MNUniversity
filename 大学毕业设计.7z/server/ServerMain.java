package server;

import javax.swing.JFrame;

class ServerMain{
    public static void main(String[] args) {
        ServerGui server = new ServerGui();
    }
}