package server;   
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.SwingWorker;  
  
public class ReceiveTask  extends SwingWorker<Integer, Object>{  
    private Socket socket;
    private String save_path;
    public ReceiveTask(Socket socket) {  
        this.socket = socket;
        save_path="";
    }
    
    
    public Socket getSocket() {
		return socket;
	}
	public void setSocket(Socket _mSocket) {
		this.socket = _mSocket;
	}
	public String getSave_path() {
		return save_path;
	}
	public void setSave_path(String save_path) {
		this.save_path = save_path;
	}
	public ReceiveTask() {
    }
    protected Integer doInBackground(){
    	System.out.println("--------------------------���տ�ʼ--------------------------");
		try{
			DataInputStream input= new DataInputStream(socket.getInputStream());
			WriteFile writer=new WriteFile();
			writer.receiveMeta(input);
			writer.setSave_path(save_path);
			writer.openFile();
			float percent=0;
			while((int)percent!=100){
				writer.receiveData(input);
				writer.writeFile();
				percent = 100.0f *(((float)writer.getOffset())+(float)writer.getData_byte().length)/((float)writer.getFile_in_size());
				this.setProgress((int)percent);
				System.out.print("���ձȣ�"+writer.getFile_in_name()+"\t"+(int)percent+"%\n");
			}
	        writer.closeFile();
	        socket.shutdownInput();
			input.close();
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	        System.out.print("--------------------------����δ��ɷ����쳣--------------------\n");
			//JOptionPane.showMessageDialog(new JOptionPane(),"����δ��ɷ����쳣"); 
			return this.getProgress();
		}
        System.out.print("--------------------------�������--------------------------\n");
        return 100;
    }  
  
}  