package server;
  
import java.awt.BorderLayout;  
import java.awt.Container;
import java.awt.FlowLayout;  
import java.awt.GridLayout;
import java.awt.event.ActionEvent;  
import java.awt.event.ActionListener;  
import java.beans.PropertyChangeEvent;  
import java.beans.PropertyChangeListener;  
import java.io.IOException;  
import java.net.ServerSocket;  
import java.net.Socket;  
  





import javax.swing.BoxLayout;  
import javax.swing.JButton;  
import javax.swing.JFrame;  
import javax.swing.JOptionPane;  
import javax.swing.JPanel;  
import javax.swing.JProgressBar;  
  
public class ServerGui extends JFrame implements ActionListener {  
    /** 
     *  
     */  
    public final static int MINIMUM = 0;  
    public final static int MAXIMUM = 100;
    private static final long serialVersionUID = 1L;
    
    public final static String PREFERENCE_CMD = "����";
    private ServerSocket serverSocket;  
    private JButton startBtn;
    //private JProgressBar bar;
    private Container container;
    private ServerPreference sp;
    public ServerGui() {
        initComponent();
        sp=new ServerPreference();
    }  
  
    private void initComponent() {  
        container=getContentPane();
        container.setLayout(new GridLayout(11,1));

        startBtn = new JButton(PREFERENCE_CMD);
        startBtn.addActionListener(this); 
        JPanel btnPanel = new JPanel(new GridLayout(1,1));  
        btnPanel.add(startBtn);
        getContentPane().add(btnPanel);
        
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        this.setTitle("����Internet�����Ĵ��乤�����-�����");
        this.setSize(500, 500);
        this.setResizable(true);
        this.setVisible(true);
		this.setLocationRelativeTo(null);
    }  
      
    private void startServer(){
			try {
				if(null==serverSocket||serverSocket.getLocalPort()!=sp.getServerPort())
					serverSocket = new ServerSocket(sp.getServerPort());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, "�˿ڰ��쳣");
			}
            System.out.println("�����˿� :" + sp.getServerPort());
            System.out.println("�洢Ŀ¼ :" + sp.getServerDir().getPath());
            while(true) {
                Socket socket = null;
				try {
					socket = serverSocket.accept();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("������������"+socket.getLocalSocketAddress());
                System.out.println("Զ����������"+socket.getRemoteSocketAddress());
                final JProgressBar bar=ProgressBarBuilder();
                ReceiveTask task = new ReceiveTask();
                task.setSocket(socket);
                task.setSave_path(sp.getServerDir().getPath());
                task.execute();
                task.addPropertyChangeListener(new PropertyChangeListener() {  
                    public void propertyChange(PropertyChangeEvent evt) {  
                        if ("progress".equals(evt.getPropertyName())) {  
                            bar.setValue((Integer)evt.getNewValue());
                            if(100==(Integer)evt.getNewValue())
                            	ProgressBarKiller(bar);
                        }
                    }
                });
            }
    }
	@Override  
    public void actionPerformed(ActionEvent e) {
        if(PREFERENCE_CMD.equals(e.getActionCommand())) {
        	sp.setVisible(true);
            Thread startThread = new Thread(new Runnable() {
                public void run() {
                    startServer();  
                }
            });
            startThread.start();
        }
        else{
        }
    }
	
	private void ProgressBarKiller(JProgressBar bar){
		container.remove(bar);
        this.paintComponents(getGraphics());
	}
	
    private JProgressBar ProgressBarBuilder(){
        JPanel progressPanel = new JPanel();
        progressPanel.setLayout(new GridLayout(1,1));
        JProgressBar bar = new JProgressBar();
        bar.setVisible(true);
        progressPanel.add(bar);
        bar.setMinimum(MINIMUM);
        bar.setMaximum(MAXIMUM);
        container.add(bar);
        this.paintComponents(getGraphics());
        return bar;
    }
    
} 