package server;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.RandomAccessFile;

public class WriteFile{
	private String file_in_name;
	private Long file_in_size;
	private long offset;
	private byte data_byte[];
	private File file_out;
	private String save_path;
	private RandomAccessFile rand_file_out;
	
	WriteFile(){
		file_in_name=null;
		file_in_size=0L;
		file_out=null;
		rand_file_out=null;
		offset=0;
		data_byte=null;
	}
	
	
	
	public void setSave_path(String save_path) {
		this.save_path = save_path;
	}
	public String getFile_in_name() {
		return file_in_name;
	}
	public long getFile_in_size() {
		return file_in_size;
	}
	public long getOffset() {
		return offset;
	}
	public byte[] getData_byte() {
		return data_byte;
	}

	
	public void receiveMeta(DataInputStream input) throws IOException{
		//�ļ���
		file_in_name=input.readUTF();
		//�ļ�����
		file_in_size=input.readLong();
		
		System.out.println("���յ��ļ�����"+file_in_name);
		System.out.println("���յ��ļ��ߴ磺"+file_in_size+"B");
		
		
	}
	public void receiveData(DataInputStream input) throws IOException{
		//�ļ�ƫ����
		offset=input.readLong();
		//���ݳ���
		int data_length=input.readInt();
		//����
		byte data_byte[]=new byte[data_length];
		input.readFully(data_byte);
		this.data_byte=data_byte;
	}
	
	public void openFile(){
		try{
			file_out=new File(save_path+file_in_name);
			if(!file_out.exists()){
				//System.out.print("�����ļ���"+file_in.getAbsolutePath()+"\n");
				file_out.createNewFile();
			}
			System.out.println("д����ļ�����"+file_out.getAbsoluteFile());
			rand_file_out=new RandomAccessFile(file_out,"rw");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void closeFile(){
		try {
			rand_file_out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void writeFile(){
		try {
			rand_file_out.seek(offset);
			rand_file_out.write(data_byte);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		

	}
	
	private Object byte2obj(byte x[]){
    	ByteArrayInputStream byte_stream=new ByteArrayInputStream(x);
    	Object read_obj = null;
		try {
	    	ObjectInputStream obj_stream=new ObjectInputStream(byte_stream);
			read_obj = obj_stream.readObject();
	    	obj_stream.close();
	    	byte_stream.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return read_obj;
	}
}