package server;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

class ServerPreference extends JDialog implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	private static String btn_okay_string="Okay";
	private static String btn_cancel_string="Cancel";
	private static String btn_select_dir_string="SelectDir";
	private JButton btn_okay;
	private JButton btn_cancel;
	private JButton btn_dir;
	private JTextField txt_port;
	private Container container;
	private File file;
	private File pre_file;
	private int pre_port;
	ServerPreference(){
		pre_port=9999;
		pre_file=new File("");//�ձ�ʾ��ǰ����·��
		initUi();
		setTitle("����д������Ϣ");
		setSize(300,300);
		setResizable(false);
		setVisible(false);
		setLocationRelativeTo(null);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        this.setModal(true);
	}
	
	void initUi(){
		JLabel label_port=new JLabel();
		label_port.setText("Server Port:");
		JLabel label_dir=new JLabel();
		label_dir.setText("Save Directory:");
		
		txt_port=new JTextField();
		txt_port.setText(Integer.toString(pre_port));
		
		btn_dir=new JButton();
		btn_dir.setText(btn_select_dir_string);
		btn_dir.addActionListener(this);
		
		btn_okay=new JButton();
		btn_okay.setText(btn_okay_string);
		btn_okay.addActionListener(this);

		btn_cancel=new JButton();
		btn_cancel.setText(btn_cancel_string);
		btn_cancel.addActionListener(this);
		
		JPanel panel=new JPanel();
		panel.setLayout(new GridLayout(3,2,5,5));
		panel.add(label_port);
		panel.add(txt_port);
		panel.add(label_dir);
		panel.add(btn_dir);
		panel.add(btn_okay);
		panel.add(btn_cancel);

		container=getContentPane();
		container.setLayout(new FlowLayout());
		container.add(panel);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		String command=event.getActionCommand();
		if(command.equals(btn_okay_string)){
			pre_port=getServerPort();
			if(null==file)
				file=pre_file;
			else
				pre_file=getServerDir();
			setVisible(false);
		}
		else if(command.equals(btn_cancel_string)){
			pre_port=getServerPort();
			if(null==file)
				file=pre_file;
			else
				pre_file=getServerDir();
			setVisible(false);
		}
		else if(command.equals(btn_select_dir_string)){
			file=selectDir();
		}
		else{
			
		}
	}
	
	//��ȡ�������˿�
	public int getServerPort(){
		return Integer.parseInt(txt_port.getText());
	}

	public File getServerDir(){
		return file;
	}
	private File selectDir(){
		JFileChooser dir=new JFileChooser();
		dir.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		int state=dir.showOpenDialog(null);
		if(state==JFileChooser.APPROVE_OPTION){
			return dir.getSelectedFile();
		}
		else
			return null;
	}
}