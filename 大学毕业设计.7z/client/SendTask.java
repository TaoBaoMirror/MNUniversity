package client;

import java.io.DataOutputStream;  
import java.io.File; 
import java.io.IOException;
import java.net.Socket;  
import java.net.SocketAddress;  
  

import java.net.SocketException;

import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.SwingWorker;  
  
public class SendTask extends SwingWorker<Integer, Object> {  
    private File file;
    private Socket socket;
    private SocketAddress address;
    private JProgressBar bar;
    
    public SendTask(File file, SocketAddress address, JProgressBar bar) {  
        this.address = address;  
        this.file = file;
        socket = new Socket();  
        this.bar = bar;
        
    }
      
    @Override
    protected Integer doInBackground(){
        System.out.println("...........................���Ϳ�ʼ..........................."); 

        try {
			socket.connect(address);
			socket.setSoLinger(true, 60);
	        DataOutputStream output = new DataOutputStream(socket.getOutputStream());
	        ReadFile reader = new ReadFile(file);
	        reader.openFile();
	        reader.sendMeta(output);
	        float percent = 0;
	        while ((int)percent!=100){
	        	reader.readData();
	        	reader.sendData(output);
	            percent = 100.0f * ((float)reader.getOffset())/((float)reader.getSendFile().length());
	            //bar.setValue((int)percent);
	            this.setProgress((int)percent);
	            System.out.print("���ͱȣ�"+percent+"%\n");
	        }
			socket.shutdownOutput();
			socket.close();
			reader.closeFile();
		} catch (IOException e2) {
			// TODO Auto-generated catch bloc
            this.setProgress(100);
			e2.printStackTrace();
	        System.out.print("--------------------------����δ��ɷ����쳣--------------------\n");
	        
			return this.getProgress();
		}
        System.out.println("...........................�������...........................");  
        return 100;
    }  
}  