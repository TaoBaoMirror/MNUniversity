package client;

import javax.swing.JFrame;

class ClientMain{
    public static void main(String[] args) {
        ClientGui client = new ClientGui();
        //SubInfo si=new SubInfo();
    }
}