package client;
  
import java.awt.BorderLayout;  
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;  
import java.awt.GridLayout;  
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;  
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.beans.Beans;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;  
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;  
import java.net.Socket;
import java.net.SocketAddress;  
  



import java.net.SocketException;
import java.net.UnknownHostException;

import javax.swing.BorderFactory;  
import javax.swing.BoxLayout;  
import javax.swing.JButton;  
import javax.swing.JFileChooser;  
import javax.swing.JFrame;  
import javax.swing.JLabel;  
import javax.swing.JOptionPane;  
import javax.swing.JPanel;  
import javax.swing.JProgressBar;  
import javax.swing.JTextField;  
/** 
 * @Date 2015-11-30 
 * @author lissa
 * 
 */  
public class ClientGui extends JFrame implements ActionListener {  
    /** 
     *  
     */  
    private static final long serialVersionUID = 1L;  
    public final static String SEND_CMD = "�����ļ�";  
    public final static int MINIMUM = 0;
    public final static int MAXIMUM = 100;
    // public final static String CONNECT_CMD = "Connect";  
    private JButton sendFileBtn;
    private ClientPreference cp;
    private Container container;
    
    public ClientGui() {
        initComponents();
    	cp=new ClientPreference();
    }
  
    private void initComponents() {
        container=getContentPane();
        container.setLayout(new GridLayout(11,1));
        sendFileBtn = new JButton(SEND_CMD);
        JPanel btnPanel = new JPanel();  
        btnPanel.setLayout(new GridLayout(1,1));
        btnPanel.add(sendFileBtn);
        
        container.add(btnPanel);
        sendFileBtn.addActionListener(this);
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        this.setTitle("����Internet�����Ĵ��乤�����-�ͻ���");
        this.setSize(500, 500);
        this.setResizable(true);
        this.setVisible(true);
		this.setLocationRelativeTo(null);
    }
    
    @Override  
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if(command.equals(SEND_CMD)) {
            Thread send_thread=new Thread(
            		new Runnable(){
            			public void run(){
            				ThreadRunner();
            				}
            			}
            		);
            send_thread.start();
        }
        else{
            // do nothing
        }
    }
    
    
    private void ThreadRunner(){
        cp.setVisible(true);
        if(!cp.isSubmit())
        	return;
        String ip=cp.getServerIp();
        int port=cp.getServerPort();
        int speed=cp.getLimitedSpeed();
        File file=cp.getFile();
    	final JProgressBar bar=ProgressBarBuilder(file.getAbsolutePath());
        SocketAddress address = new InetSocketAddress(ip,port);
        SendTask task = new SendTask(file, address, bar);
        task.execute();
        task.addPropertyChangeListener(new PropertyChangeListener() {  
            public void propertyChange(PropertyChangeEvent evt) {  
                if ("progress".equals(evt.getPropertyName())) {  
                    bar.setValue((Integer)evt.getNewValue());
                    if(100==(Integer)evt.getNewValue())
                    	ProgressBarKiller(bar);
                }
            }
        });
    }

    private  void ProgressBarKiller(JProgressBar bar){
        container.remove(bar);
        this.paintComponents(getGraphics());
    }
    
    private JProgressBar ProgressBarBuilder(String file_name){
        JPanel progressPanel = new JPanel();
        progressPanel.setLayout(new GridLayout(1,1));
        JProgressBar bar = new JProgressBar();
        bar.setString(file_name);
        bar.setStringPainted(true);
        bar.setVisible(true);
        progressPanel.add(bar);
        bar.setMinimum(MINIMUM);
        bar.setMaximum(MAXIMUM);
        container.add(bar);
        this.paintComponents(getGraphics());
        return bar;
    }
    
} 