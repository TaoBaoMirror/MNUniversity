package client;

import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneLayout;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

class ClientPreference extends JDialog implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	private static String btn_okay_string="Okay";
	private static String btn_cancel_string="Cancel";
	private static String btn_select_file_string="Select File";
	
	private JButton btn_okay;
	private JButton btn_cancel;
	private JTextField txt_ip;
	private JTextField txt_port;
	private JTextField txt_speed;
	private JTextArea txt_state;
	private JButton btn_select_file;
	
	
	private File selected_file; 
	
	private boolean isSubmit;
	
	ClientPreference(){
		initUi();
		setTitle("����д������Ϣ-�ͻ���");
		setSize(350,350);
		setResizable(false);
		setVisible(false);
		setLocationRelativeTo(null);
        setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
        this.setModal(true);
        selected_file=null;
        isSubmit=true;
	}
	
	void initUi(){
		JLabel label_ip=new JLabel();
		JLabel label_port=new JLabel();
		JLabel label_speed=new JLabel();
		JLabel label_file=new JLabel();
		JLabel label_state=new JLabel();
		label_ip.setText("Server IP/Host:");
		label_port.setText("Server Port:");
		label_speed.setText("Limited Speed:");
		label_file.setText("Select File:");
		label_state.setText("Current State:");
		

		txt_ip=new JTextField(10);
		txt_port=new JTextField(10);
		txt_speed=new JTextField(10);
		txt_state=new JTextArea(8,21);
		txt_ip.setText("127.0.0.1");
		txt_port.setText("9999");
		txt_speed.setText("1000");
		txt_speed.setEditable(false);
		//txt_state.setForeground(new Color(255,0,0));
		txt_state.setEditable(false);
		
		btn_select_file=new JButton();
		btn_select_file.setText(btn_select_file_string);
		btn_select_file.addActionListener(this);
		
		btn_okay=new JButton();
		btn_okay.setText(btn_okay_string);
		btn_okay.addActionListener(this);
		btn_cancel=new JButton();
		btn_cancel.setText(btn_cancel_string);
		btn_cancel.addActionListener(this);
		
		JPanel panel=new JPanel();
		panel.setLayout(new GridLayout(5,2,5,5));
		panel.add(label_ip);
		panel.add(txt_ip);
		panel.add(label_port);
		panel.add(txt_port);
		panel.add(label_speed);
		panel.add(txt_speed);
		panel.add(label_file);
		panel.add(btn_select_file);
		panel.add(btn_okay);
		panel.add(btn_cancel);
		

		JScrollPane panel_state=new JScrollPane(txt_state);
		panel_state.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		panel_state.setLayout(new ScrollPaneLayout());
		//panel_state.add(txt_state);
		panel_state.setVisible(true);
		
		Container container=getContentPane();
		container.setLayout(new FlowLayout());
		container.add(panel);
		container.add(panel_state);
	}
	
	
	public boolean isSubmit(){
		return isSubmit;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		String command=event.getActionCommand();
		if(command.equals(btn_okay_string)){
			isSubmit=true;
			if(checkState())
				setVisible(false);
			else
				setVisible(true);
				
		}
		else if(command.equals(btn_cancel_string)){
			isSubmit=false;
			setVisible(false);
		}
		else if(command.equals(btn_select_file_string)){
			selected_file=selectFile();
		}
	}

    @Override
    protected void processWindowEvent(WindowEvent e){
    	if(e.getID()==WindowEvent.WINDOW_CLOSING){
			isSubmit=false;
			setVisible(false);
			
    	}
    }
	private File selectFile(){
        JFileChooser chooser = new JFileChooser();
        int state=chooser.showOpenDialog(null);
        if(state==JFileChooser.APPROVE_OPTION)
        	return chooser.getSelectedFile();
        else
        	return null;
	}
	
	//��ȡ������Ip
	public String getServerIp(){
		return txt_ip.getText();
	}
	//��ȡ�������˿�
	public int getServerPort(){
		if(null==txt_port.getText())
			return -1;
		return Integer.parseInt(txt_port.getText());
	}
	public int getLimitedSpeed(){
		return Integer.parseInt(txt_speed.getText());
	}
	public File getFile(){
		return selected_file;
	}
	
	private boolean checkState(){
		
		String state="Host\t\t";
		boolean check_ip=false;
		boolean check_port=false;
		boolean check_speed=false;
		boolean check_file=false;
		
		if(null!=getServerIp()){
			state+="[TRUE]";
			check_ip=true;
		}
		else
			state+="[FALSE]";
		state+="\n";
		
		state+="Port\t\t";
		if(-1!=getServerPort()){
			state+="[TURE]";
			check_port=true;
		}
		else
			state+="[FALSE]";
		state+="\n";
		
		
		state+="Speed\t\t[TRUE]\n";
		check_speed=true;

		state+="File\t\t";
		if(null!=selected_file){
			state+="[TURE]";
			check_file=true;
		}
		else
			state+="[FALSE]";
		state+="\n";
		
		txt_state.append(state);

		txt_state.append("-------------------------------------------------------\n");

		txt_state.setCaretPosition(txt_state.getText().length());
		if(check_ip&&check_port&&check_speed&&check_file)
			return true;
		else
			return false;
				
	}
    //��������ɴ���
    private boolean checkReachable(){
    	boolean state=false;
    	if(null==getServerIp())
    		return false;
        try {
        	state=InetAddress.getByName(getServerIp()).isReachable(2*1000);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(state)
			return true;
		else
			return false;
    }
}