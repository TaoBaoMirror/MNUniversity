package client;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
public class ReadFile{
	private File file;//��ǰ�ļ�
	private RandomAccessFile rand_file;
	private long offset;//ƫ����
	private int data_length_max;//�����󳤶�
	private byte[] data_byte;
	
	public ReadFile(File file){
		this.file=file;
		offset=0;
		data_length_max=1024;//Ĭ�ϴ���B
	}
	
	public void openFile(){
		try {
			rand_file=new RandomAccessFile(file,"r");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void closeFile(){
		try {
			rand_file.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void setReadSize(int size){
		data_length_max=size;
	}
	
	public File getSendFile(){
		return file;
	}
	
	public long getOffset(){
		//System.out.print("���͵��ļ�ƫ������"+offset+"\n");
		return offset;
	}
	
	//�������л�
	private byte[] obj2byte(Object obj){
		ByteArrayOutputStream byte_stream=new ByteArrayOutputStream();
		ObjectOutputStream obj_stream = null;
		try {
			obj_stream = new ObjectOutputStream(byte_stream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			obj_stream.writeObject(obj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		byte byte_array[]=byte_stream.toByteArray();
		try {
			obj_stream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	try {
			byte_stream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return byte_array;
	}
	
	
	public void sendMeta(DataOutputStream output){
		try {
			output.writeUTF(file.getName());
			output.writeLong(file.length());
			System.out.println("���͵��ļ�����"+file.getAbsolutePath());
			System.out.println("���͵��ļ��ߴ磺"+file.length()+" B");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
	}
	public void sendData(DataOutputStream output) throws IOException{
			output.writeLong(offset);
			output.writeInt(data_byte.length);
			output.write(data_byte);
			output.flush();
			offset+=data_byte.length;
			/*
			System.out.println("���͵��ļ�ƫ������"+offset);
			System.out.println("���͵����ݳ��ȣ�"+data_byte.length);
			System.out.println("���͵����ݣ�");
			for(byte x:data_byte)
				System.out.print(x);
			System.out.println("");
			*/
	}
	//��ȡ�ļ�����
	public void readData(){
		try {
			byte data_byte[]=new byte[data_length_max];
			rand_file.seek(offset);
			int has_read = rand_file.read(data_byte, 0, data_byte.length);
			if(has_read==-1)
				has_read=0;
			byte tmp[]=new byte[has_read];
			for(int i=0;i<has_read;i++)
				tmp[i]=data_byte[i];
			this.data_byte=tmp;
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		catch(IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
	}
}