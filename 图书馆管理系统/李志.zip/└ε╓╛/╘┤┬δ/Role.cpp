#include "Role.h"


Role::Role(void)
{
	ID="0000";
	password="123456";
	privilege=1;
}


Role::~Role(void)
{
}
