#include "Books.h"


Books::Books(void)
{
	subID=0;
	state=0;
	ID="";
}


Books::~Books(void)
{
}
