#include "Book.h"


Book::Book(void)
{
	ISBN="";
	CLCN="";
	name="";
	writer="";
	printers="";
	price=0;
	remark="";
}


Book::~Book(void)
{
}
