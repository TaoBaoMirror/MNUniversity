#include "Borrower.h"


Borrower::Borrower(void)
{
	ID="";
	password="";
	name="";
	privilege=0;
	address="";
	bookslimit=3;
}


Borrower::~Borrower(void)
{
}
