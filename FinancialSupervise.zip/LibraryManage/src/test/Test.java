package test;

import beans.DBCon;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DBCon dbcon=new DBCon();
		dbcon.close();
	}
}
