package dao;

public class Delete {

	public Delete() {
		// TODO Auto-generated constructor stub
	}

}
