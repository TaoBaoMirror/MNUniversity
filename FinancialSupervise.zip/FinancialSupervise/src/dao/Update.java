package dao;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Vector;

public class Update {
	private Class c;
	private String table;
	private Field f[];
	private Method m[];
	
	private String sql;
	private Vector <String> column_name;
	private Vector <String> column_value;
	private Vector <String> column_type;
	
	public Update() {
		column_name=new Vector <String>();
		column_value=new Vector <String>();
		column_type=new Vector <String>();
		// TODO Auto-generated constructor stub
	}
	public void create(Object obj){
		extractTableColumnTypeValue(obj);
		generateSQL();
		System.out.println(sql);
	}
	
	
	private void extractTableColumnTypeValue(Object obj)//����javaBean���ȡ���������������ͣ�ֵ
	{
		c=obj.getClass();//����
		f=c.getDeclaredFields();//����
		m=c.getMethods();//����
		
		table=c.getName().substring(c.getName().lastIndexOf(".")+1);//��ȡ����
		System.out.println("������"+table);
		for(int i=0;i<m.length;i++){//��ȡ����,����,ֵ
			if(m[i].getName().startsWith("get")&&!m[i].getName().startsWith("getClass")){
				String name_total=m[i].getName();//��ȡ����
				String name=name_total.substring(3,name_total.length());
				column_name.add(name);
				System.out.println(name);
				
				String type_total=m[i].getReturnType().toString();//��ȡ����
				String type=type_total.substring(type_total.lastIndexOf(".")+1,type_total.length());
				column_type.add(type);
				System.out.println(type);
				
				try {//��ȡ����ֵ
					Object value=m[i].invoke(obj,null);
					column_value.add(value.toString());
					//System.out.println("ִ�з������ص�ֵ��" + value);
				}catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}
		}
	}
	
	private void generateSQL()
	{
		sql="update";//����SQL���
		sql+=" "+table;
		sql+=" set";

		for(int i=0;i<column_name.size()-1;i++){//��ֵ����=��ֵ
			sql+=" "+column_name.get(i)+" = ";
			if(column_type.get(i).equals("String")){
				sql+="'"+column_value.get(i)+"'";
			}
			else if(column_type.get(i).equals("int"))
				sql+=column_value.get(i);
			sql+=",";
		}
		sql+=" "+column_name.get(column_name.size()-1)+" = ";
		if(column_type.get(column_name.size()-1).equals("String")){
			sql+="'"+column_value.get(column_name.size()-1)+"'";
		}
		else if(column_type.get(column_name.size()-1).equals("int"))
			sql+=column_value.get(column_name.size()-1);
		//��λ����
		sql+=" where";
	}
}
