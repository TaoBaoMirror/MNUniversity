package dao;

public class Retrieve {

	public Retrieve() {
		// TODO Auto-generated constructor stub
	}

}
