package test;

import beans.Stock;
import beans.User;
import dao.Create;
import dao.DBCon;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DBCon dbcon=new DBCon();
		dbcon.close();
		Stock s=new Stock();
		Create c=new Create();
		s.setIns_name("");
		s.setOffice("");
		s.setSto_name("ũ˰��");
		c.create(s);
	}
}