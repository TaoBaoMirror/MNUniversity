package beans;

public class Project {

	String pro_id;
	String name;
	String fund;
	public Project() {
		// TODO Auto-generated constructor stub
	}

	public String getPro_id() {
		return pro_id;
	}
	public void setPro_id(String pro_id) {
		this.pro_id = pro_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFund() {
		return fund;
	}
	public void setFund(String fund) {
		this.fund = fund;
	}
}
