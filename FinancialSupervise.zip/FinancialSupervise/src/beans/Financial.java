package beans;

public class Financial {

	int fin_id;
	String sto_name;
	String ins_name_principal;
	String ins_name_subordinate;
	String down_fund;
	int down_count;
	String pro_id;
	
	public Financial() {
		// TODO Auto-generated constructor stub
	}

	public int getFin_id() {
		return fin_id;
	}

	public void setFin_id(int fin_id) {
		this.fin_id = fin_id;
	}

	public String getSto_name() {
		return sto_name;
	}

	public void setSto_name(String sto_name) {
		this.sto_name = sto_name;
	}

	public String getIns_name_principal() {
		return ins_name_principal;
	}

	public void setIns_name_principal(String ins_name_principal) {
		this.ins_name_principal = ins_name_principal;
	}

	public String getIns_name_subordinate() {
		return ins_name_subordinate;
	}

	public void setIns_name_subordinate(String ins_name_subordinate) {
		this.ins_name_subordinate = ins_name_subordinate;
	}

	public String getDown_fund() {
		return down_fund;
	}

	public void setDown_fund(String down_fund) {
		this.down_fund = down_fund;
	}

	public int getDown_count() {
		return down_count;
	}

	public void setDown_count(int down_count) {
		this.down_count = down_count;
	}

	public String getPro_id() {
		return pro_id;
	}

	public void setPro_id(String pro_id) {
		this.pro_id = pro_id;
	}
}
