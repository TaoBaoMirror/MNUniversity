package beans;

public class Institution {
	String ins_name;
	String address;
	String office;
	String sto_name;
	public Institution() {
		// TODO Auto-generated constructor stub
	}

	public void setSto_name(String sto_name) {
		this.sto_name = sto_name;
	}

	public String getIns_name() {
		return ins_name;
	}

	public void setIns_name(String ins_name) {
		this.ins_name = ins_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public String getSto_name() {
		return sto_name;
	}
}
