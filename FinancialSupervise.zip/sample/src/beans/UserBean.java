package beans;

import java.sql.*;

public class UserBean {

    private String username;  
    private String password;
    
    public UserBean(){
    	username="";
    	password="";
    }
    public String getPassword() {
        return password;  
    }  
    public void setPassword(String password) {  
        this.password = password;  
    }  
    public String getUsername() {  
        return username;  
    }  
    public void setUsername(String username) { 
        this.username = username;  
    }  
    
    public boolean checkUser(){
    	ResultSet rs=null;
    	DBCon db=new DBCon();
    	
    	if(db.getConn()==null)
    		System.out.println("�������ݿ�ָ��Ϊ��");
        if(!username.isEmpty()&&!password.isEmpty()){
        	System.out.println("�û��������룺"+username+"��"+password);
            rs=db.doSelect("select * from db_user where userName='"+username+"'");
            try {
				if(rs.next()){
					if(password.equals(rs.getString("userPasswd"))){ 
						return true;
					}  
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
        }
        return false;  
          
    } 
}
