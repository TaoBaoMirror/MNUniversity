package test;

import java.sql.ResultSet;
import java.sql.SQLException;

import beans.UserBean;


public class TestSrc {

	public static void main(String[] args) throws SQLException, Exception {
//		String sql_ins="insert into db_user values(3,'test','test')";
//		String sql_del="delete from db_user where userId=3";
//		String sql_sch="select * from db_user where userId=1";
//		String sql_up="update db_user set userPasswd='admin' where userId=2";
//		DBCon dbc=new DBCon();
//		dbc.doInsert(sql_ins);
//		dbc.doDelete(sql_del);
//		dbc.doUpdate(sql_up);
//		ResultSet rs=dbc.doSelect(sql_sch);
//		if(rs.next()){
//			System.out.println(rs.getString(1));
//		}
//		else{
//			System.out.println("û�н����");
//		}
//		dbc.close();
//		dbc.doInsert(sql_ins);
		UserBean ub=new UserBean();
		ub.setPassword("admin");
		ub.setUsername("admin");
		if(ub.checkUser())
		{
			System.out.print("OK");
		}
		else{
			System.out.print("NK");
		}
		
	}

}
