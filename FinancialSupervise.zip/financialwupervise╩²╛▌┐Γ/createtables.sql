create table stock(
	sto_name varchar(64),
	office varchar(64),
	ins_name varchar(64),
	primary key (sto_name)
);

create table institution(
	ins_name varchar(64),
	address varchar(64),
	office varchar(64),
	sto_name varchar(64),
	primary key(ins_name),
	foreign key(sto_name) references stock(sto_name) on delete cascade
);


create table user(
	user_id varchar(64),
	password varchar(64),
	ins_name varchar(64),
	primary key(user_id),
	foreign key(ins_name) references institution(ins_name) on delete cascade
);

create table project(
	pro_id varchar(64),
	name varchar(64),
	fund varchar(64),
	primary key(pro_id)
);

create table financial(
	fin_id integer,
	sto_name varchar(64),
	ins_name_principal varchar(64),
	ins_name_subordinate varchar(64),
	down_fund varchar(64),
	down_count integer,
	pro_id varchar(64),
	primary key(fin_id),
	foreign key(sto_name) references stock(sto_name) on delete cascade,
	foreign key(pro_id) references project(pro_id) on delete cascade
);


