show databases;


drop database financialsupervision;

create database financialsupervision;

use financialsupervision;

show tables;

describe institution;

describe stock;

describe user;

describe project;

describe financial;

select *from stock;
select *from user;
select *from project;
select *from institution;
select *from financial;
